package com.searchboard;

public class Main {

	public static void main(String[] args) {
		// ProcBoard 객체를 생성
		ProcBoard procBoard = new ProcBoard();

		// ProcBoard 클래스의 run 메서드를 실행하여 프로그램을 시작
		procBoard.run();
	}
}